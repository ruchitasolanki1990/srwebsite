export const COMPANY_NAME = "SR TEFCOAT ENGINEERING";
export const GET_HOME_DETAILS= "homedetails";
export const GET_CONTACT_DETAILS= "contactdetails";
export const GET_ABOUT_DETAILS= "aboutdetails";