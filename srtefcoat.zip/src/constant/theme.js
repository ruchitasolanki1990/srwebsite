export const PRAIMARY_COLOR='white';
export const SECONDARY_COLOR=['#e97c1f'];